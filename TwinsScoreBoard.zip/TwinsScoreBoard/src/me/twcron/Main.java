package me.twcron;


import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import me.twcron.Utils.BlinkEffect;
import me.twcron.Utils.Scroller;

public class Main extends JavaPlugin implements Listener{
	
	
	
	public static Main plugin;
	public static Scroller sc;
	public static Updater up;
	public static BlinkEffect bk = new BlinkEffect();
	
	HashMap<String, Updater> pScores = new HashMap<String, Updater>();
	
	public void onEnable(){
		plugin = this;
		sc = new Scroller("    �2Servidor Full PvP inovador!", 16, 16, '�');
		getServer().getPluginManager().registerEvents(this, this);
		Bukkit.getConsoleSender().sendMessage("�f�l[�b�lTwins�4�lBoard�f�l] �aPlugin ativado!");
		up = new Updater();
	    new BukkitRunnable() {
	        public void run() {
	            for (Player p : Bukkit.getOnlinePlayers()) {
	                if (!pScores.containsKey(p.getName())) {
	                    pScores.put(p.getName(), new Updater());
	                }
	            }
	        }
	    }.runTaskTimer(this, 1, 2L);
		
	}
	
	@Override
	public void onDisable() {
		Bukkit.getConsoleSender().sendMessage("�f�l[�b�lTwins�4�lBoard�f�l] �aPlugin desativado!");
	}
	
	
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e){
		Player p = e.getPlayer();
		up.build(p);
		
	    new BukkitRunnable() {
	        public void run() {
	            for (Player p : Bukkit.getOnlinePlayers()) {
	                if (!pScores.containsKey(p.getName())) {
	                    pScores.put(p.getName(), new Updater());
	                }
	            }
	        }
	    }.runTaskTimer(this, 0, 3*20L);
	}
    
    public Main getMe() {
        return this;
    }
}