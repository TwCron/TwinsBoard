package me.twcron.Utils;

public class BlinkEffect {
	
	private int i = 1;
	private String texto = "�b�lTwins�4�lFlammer";
	public BlinkEffect(){
		
	}
	
	public void next(){
		if (i == 1){
			texto = "�b�lT";
		}
		if (i == 2){
			texto = "�b�lTw";
		}
		if (i == 3){
			texto = "�b�lTwi";
		}
		if (i == 4){
			texto = "�b�lTwin";
		}
		if (i == 5){
			texto = "�b�lTwins";
		}
		if (i == 6){
			texto = "�b�lTwins�4�lF";
		}
		if (i == 7){
			texto = "�b�lTwins�4�lFl";
		}
		if (i == 8){
			texto = "�b�lTwins�4�lFla";
		}
		if (i == 9){
			texto = "�b�lTwins�4�lFlam";
		}
		if (i == 10){
			texto = "�b�lTwins�4�lFlamm";
		}
		if (i == 11){
			texto = "�b�lTwins�4�lFlamme";
		}
		if (i == 12){
			texto = "�b�lTwins�4�lFlammer";
		}
		if (i == 13){
			texto = "";
		}
		if (i == 14){
			texto = "�4�lTwins�b�lFlammer";
		}
		if (i == 15){
			texto = "";
		}
		if (i == 16){
			texto = "�b�lTwinsFlammer";
		}
		if (i == 17){
			texto = "�4�lTwinsFlammer";
			i = 0;
		}
		i++;
		
		
	}
	public String getText(){
		return texto;
	}

}
