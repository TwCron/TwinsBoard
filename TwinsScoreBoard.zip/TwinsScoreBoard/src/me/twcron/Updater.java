package me.twcron;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import me.twcron.Utils.FastOfflinePlayer;
import net.minecraft.server.v1_8_R3.EntityPlayer;
import ru.tehkode.permissions.bukkit.PermissionsEx;

public class Updater {
	
	public Updater(){
		this.run();
	}
	
	private void run(){
		new BukkitRunnable() {
			
			@Override
			public void run() {
				for (Player p : Bukkit.getOnlinePlayers()){
					Update(p.getScoreboard(), p);
				}
				
			}
		}.runTaskTimer(Main.plugin, 0, 3*20L);
	}
	@SuppressWarnings("deprecation")
	public void build(Player p){
		Scoreboard score = Bukkit.getScoreboardManager().getNewScoreboard();
		Objective obj = score.registerNewObjective("sbanimado", "dummy");
		obj.setDisplaySlot(DisplaySlot.SIDEBAR);
		obj.setDisplayName("�b�lTwins�4�lFlammer");
		
		// Linha 0
		FastOfflinePlayer line0 = new FastOfflinePlayer("�r");
		Team l0 = score.registerNewTeam("linha0");
		l0.setPrefix("�7�l");
		l0.addPlayer(line0);
		obj.getScore(line0).setScore(15);
		p.setScoreboard(score);
		
		// Linha 1
		FastOfflinePlayer line1 = new FastOfflinePlayer("�0");
		obj.getScore(line1).setScore(2);
		
		// Linha 2
		FastOfflinePlayer line2 = new FastOfflinePlayer("�1");
		Team l1 = score.registerNewTeam("linha2");
		l1.setPrefix("�7   Loading...");
		l1.addPlayer(line2);
		obj.getScore(line2).setScore(1);
		p.setScoreboard(score);
		
		// Linha 3
		
		FastOfflinePlayer line3 = new FastOfflinePlayer(" Atuais �");
		Team l3 = score.registerNewTeam("linha3");
		l3.setPrefix("�a  Jogadores"); l3.setSuffix("Loading...");
		l3.addPlayer(line3);
		obj.getScore(line3).setScore(14);
		
		// Linha 4
		FastOfflinePlayer line4 = new FastOfflinePlayer("�a Atual � �2");
		Team l4 = score.registerNewTeam("linha4");
		l4.setPrefix("�a  Rank");
		l4.addPlayer(line4);
		obj.getScore(line4).setScore(12);
		p.setScoreboard(score);
		
		// Linha 5
		FastOfflinePlayer line5 = new FastOfflinePlayer("�f");
		Team l5 = score.registerNewTeam("linha5");
		l5.setPrefix("");
		l5.addPlayer(line5);
		obj.getScore(line5).setScore(13);
		p.setScoreboard(score);
		
		// Linha 7
		FastOfflinePlayer line7 = new FastOfflinePlayer("�4");
		Team l7 = score.registerNewTeam("linha7");
		l7.setPrefix("");
		l7.addPlayer(line7);
		obj.getScore(line7).setScore(11);
		p.setScoreboard(score);
		
		
		
		// Linha 6
		FastOfflinePlayer line6 = new FastOfflinePlayer("�aAtual � ");
		Team l6 = score.registerNewTeam("linha6");
		l6.addPlayer(line6);
		l6.setPrefix("�a  Hor�rio ");
		obj.getScore(line6).setScore(10);
		p.setScoreboard(score);
		
		// Linha 9
		FastOfflinePlayer line9 = new FastOfflinePlayer("�9");
		Team l9 = score.registerNewTeam("linha9");
		l9.addPlayer(line9);
		l9.setPrefix("�5");
		obj.getScore(line9).setScore(9);
		p.setScoreboard(score);
		
		// Linha 8
		FastOfflinePlayer line8 = new FastOfflinePlayer("�aAtual ��2 ");
		Team l8 = score.registerNewTeam("linha8");
		l8.addPlayer(line8);
		l8.setPrefix("�a  Ping ");
		obj.getScore(line8).setScore(8);
		p.setScoreboard(score);
		
	}
	
	//Scoreboard

	private String getData(Player p){
	  SimpleDateFormat format = new SimpleDateFormat("hh:mm");
	        String d = format.format(new Date());
	  if (d.length() > 16){
	   d = d.substring(0, 16);
	  }
	  
	return d;}

	private int getPing(Player p){
        CraftPlayer cp = (CraftPlayer) p;
        EntityPlayer entityPlayer = cp.getHandle();

        return entityPlayer.ping;
    }
	
	public void Update(final Scoreboard score,final Player p){
		Thread th = new Thread(new Runnable() {
			
			@Override
			public void run() {
				Team t = score.getTeam("linha2");
				t.setPrefix("�7     ");
				t.setSuffix(Main.sc.next());
				
				Team t2 = score.getTeam("linha3");
				t2.setSuffix("�a " + Bukkit.getOnlinePlayers().size() + "�2/�a" + Bukkit.getMaxPlayers());
				
				Team l6 = score.getTeam("linha6");
				l6.setSuffix(getData(p));
				
				String ping = Integer.toString(getPing( p ));
				
				Team l8 = score.getTeam("linha8");
				l8.setSuffix(ping);
				
				@SuppressWarnings("deprecation")
				String prefix = PermissionsEx.getUser(p.getPlayer()).getGroups()[0].getName();
				
				Team l4 = score.getTeam("linha4");
				l4.setSuffix(prefix);
				
				Objective obj = score.getObjective("sbanimado");
				obj.setDisplayName(Main.bk.getText());
				
				
			}
		});
		th.start();
	}
	

}
